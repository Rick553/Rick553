print("Hello")
print("Welcome to github")
